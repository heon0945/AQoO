package org.com.ssafy_poc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsafyPocApplication {

	public static void main(String[] args) {
		SpringApplication.run(SsafyPocApplication.class, args);
	}

}
