package org.com.ssafy_poc.config;

import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

public class WebConfig implements WebMvcConfigurer {
	private static final String DEVELOP_FRONT_ADDRESS = "http://localhost:3000";

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/**")
			// .allowedOrigins("http://localhost:3000", "https://production-url.com")
			.allowedOrigins("http://localhost:3000", "https://production-url.com") // 개발 및 배포 환경
			.allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
			.allowedHeaders("*")
			.allowCredentials(true);
	}
}
