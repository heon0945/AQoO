package org.com.ssafy_poc.domain.chat.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.com.ssafy_poc.domain.chat.dto.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class ChatController {


	private static final Logger logger = LoggerFactory.getLogger(ChatController.class);

	private final ConcurrentHashMap<String, ConcurrentLinkedQueue<String>> roomMembers = new ConcurrentHashMap<>();

	// 클라이언트에서 /app/chat.addUser/{roomId} 요청 시 처리
	@MessageMapping("/chat.addUser/{roomId}")
	@SendTo("/topic/{roomId}")
	public Message addUser(@DestinationVariable String roomId, Message message) {
		roomMembers.computeIfAbsent(roomId, k -> new ConcurrentLinkedQueue<>()).add(message.getSender());
		message.setContent(message.getSender() + " joined room " + roomId + ".");
		logger.info("User {} joined room {}", message.getSender(), roomId);
		return message;
	}

	// 클라이언트에서 /app/chat.sendMessage/{roomId} 요청 시 처리
	@MessageMapping("/chat.sendMessage/{roomId}")
	@SendTo("/topic/{roomId}")
	public Message sendMessage(@DestinationVariable String roomId, Message message) {
		logger.info("User {} sent message to room {}: {}", message.getSender(), roomId, message.getContent());
		return message;
	}

	// REST API로 방 멤버 조회
	@GetMapping("/rooms/{roomId}/members")
	public List<String> getRoomMembers(@PathVariable String roomId) {
		return new ArrayList<>(roomMembers.getOrDefault(roomId, new ConcurrentLinkedQueue<>()));
	}

}
