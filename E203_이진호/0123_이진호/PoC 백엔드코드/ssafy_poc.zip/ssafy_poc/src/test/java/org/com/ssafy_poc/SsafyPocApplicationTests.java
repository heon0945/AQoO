package org.com.ssafy_poc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsafyPocApplicationTests {

	@Test
	void contextLoads() {
	}

}
